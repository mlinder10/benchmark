import mondaySdk from "monday-sdk-js";

export const monday = mondaySdk();
